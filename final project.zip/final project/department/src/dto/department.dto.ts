export class createDepartmentDto{
    id:number
    name:string
    email:string
}