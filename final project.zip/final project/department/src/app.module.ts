import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { DepartmentModule } from './department/department.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { department } from './typeorm/department.entity';
@Module({
  imports: [TypeOrmModule.forRoot({
    type: 'postgres',
      host: 'localhost',
      port: 6969,
      username: 'postgres',
      password: 'Sahil@2022',
      database: 'postgres',
      entities: [department],
      synchronize: true
    }),
    DepartmentModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
