import {Column, Entity, PrimaryGeneratedColumn} from 'typeorm'
@Entity('department')
export class department{
@PrimaryGeneratedColumn()
id:number
@Column()
name:string
@Column()
email:string    
}