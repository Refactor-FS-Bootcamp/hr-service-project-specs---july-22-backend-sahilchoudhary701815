import { Controller,Get } from '@nestjs/common';
import { EventPattern } from '@nestjs/microservices';
import { createDepartmentDto } from 'src/dto/department.dto';
import { DepartmentService } from './department.service';

@Controller('department')
export class DepartmentController {
    constructor(private departmentservice:DepartmentService){}
    @Get()
    sendhello(){
        return 'hello'
    }
    @EventPattern('hello')
    hello(data:any){
        this.departmentservice.createdepartment(data)
        console.log(data)
        
    }
    @EventPattern('delete')
    delete(data:any){
        this.departmentservice.deletedepartment(data.id)
    }
    @EventPattern('show')
    show(){
        this.departmentservice.showDepartment()
    }
    }
