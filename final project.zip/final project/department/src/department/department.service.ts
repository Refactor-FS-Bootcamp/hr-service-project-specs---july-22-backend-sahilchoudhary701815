import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { department } from 'src/typeorm/department.entity';
import { Repository } from 'typeorm';
import { createDepartmentDto } from 'src/dto/department.dto';
@Injectable()
export class DepartmentService {
    constructor(@InjectRepository(department) public repo:Repository<department>){}
    showDepartment(){
        return this.repo.find()
    }
    createdepartment(createdepartmentdto:createDepartmentDto){
        const data=this.repo.create(createdepartmentdto)
        console.log('req recieved')
        return this.repo.save(data)
    }
    deletedepartment(id:number){
        this.repo.delete(id)
    }
}
